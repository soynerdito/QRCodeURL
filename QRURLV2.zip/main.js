// May 2013, Soynerdito
// Based on chrome context menu examples

// The onClicked callback function.
function onClickHandler(info, tab) {
  if( info.menuItemId == "showqrcode" ) {
    console.log("selected = " + info.selectionText );
	showQRCode(info.selectionText);
  }
};

function showQRCode(selectedText) {
  var serviceCall = 'http://chart.apis.google.com/chart?cht=qr&chs=350x350&chld=M&choe=UTF-8&chl=' + selectedText;
  chrome.tabs.create({url: serviceCall});  
}

chrome.contextMenus.onClicked.addListener(onClickHandler);

// Set up context menu tree at install time.
chrome.runtime.onInstalled.addListener(function() {
  // Create one test item for each context type.
  var id = chrome.contextMenus.create({"title": "QR Code from selection", contexts:["selection"],
                                         "id": "showqrcode"});

});
